Hello,

Thank for downloading TheTravelista Font.

NOTE: 
This is a demo font  for PERSONAL USE ONLY! But any donation are very appreciated. 

Paypal account for donation : https://paypal.me/yusufsangdes 
to purchase full version and commercial license: you can email me at yusufsangdes@gmail.com 


And follow my instagram for update : @Typemaczstudio

If there is a problem, question, or anything about my fonts, please sent an email to

yusufsangdes@gmail

For buy our Premium Font let see our Font Shop here:

https://fontbundles.net/typemacz-studio
https://creativemarket.com/Typemacz

Thanks,

Typemacz Studio